<?php
// Connection details for our database
  $dbconnect = mysqli_connect("localhost", "root", "", "cars");
 ?>
