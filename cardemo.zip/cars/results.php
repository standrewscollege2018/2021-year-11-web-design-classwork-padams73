<?php
  include("dbconnect.php");
 ?>
<!-- Get the value entered in the search field and store it in a variable
  Make sure you check if it is set first -->

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Search results</title>
  </head>
  <body>
    <!-- Search the car table to see if there are any cars that have a
          numberplate, make or model that matches the search.
          If there are, display them in a do while loop.
          If not, display "No results found". -->



  </body>
</html>
